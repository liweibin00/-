package com.mytest.ProConversion;

public class Msql {
    private String tableName;
    private String fieldName;
    private String dataType;
    private String desc;
    private String format;
    private String init;
    private String lable;
    private String posi;
    private String maxWidth;
    private String coloLable;
    private String deci;
    private String valExp;
    private String valMsg;
    private String order;
    private String ismand;

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public void setInit(String init) {
        this.init = init;
    }

    public String getInit() {
        return init;
    }

    public void setLable(String lable) {
        this.lable = lable;
    }

    public String getLable() {
        return lable;
    }

    public void setPosi(String posi) {
        this.posi = posi;
    }

    public String getPosi() {
        return posi;
    }

    public void setMaxWidth(String maxWidth) {
        this.maxWidth = maxWidth;
    }

    public String getMaxWidth() {
        return maxWidth;
    }

    public void setColoLable(String coloLable) {
        this.coloLable = coloLable;
    }

    public String getColoLable() {
        return coloLable;
    }

    public void setDeci(String deci) {
        this.deci = deci;
    }

    public String getDeci() {
        return deci;
    }

    public void setValExp(String valExp) {
        this.valExp = valExp;
    }

    public String getValExp() {
        return valExp;
    }

    public void setValMsg(String valMsg) {
        this.valMsg = valMsg;
    }

    public String getValMsg() {
        return valMsg;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getOrder() {
        return order;
    }

    public void setIsmand(String ismand) {
        this.ismand = ismand;
    }

    public String getIsmand() {
        return ismand;
    }
}
