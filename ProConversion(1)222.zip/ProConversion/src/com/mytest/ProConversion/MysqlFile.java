package com.mytest.ProConversion;

import com.sun.jdi.Value;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MysqlFile {

    private List<Msql> msqls = new ArrayList<>();

    File f;

    public MysqlFile(List<Msql> msqls) {
        this.msqls = msqls;
    }

    //创建表
    public void CreateTable(String TableName) throws IOException {

        this.f = new File("./src/com/mytest/ProConversion/" + TableName + ".sql");

        try (FileWriter fw = new FileWriter(f);
             PrintWriter pw = new PrintWriter(fw);) {
            pw.println("DROP TABLE IF EXISTS `" + TableName + "`;");
            pw.println("CREATE TABLE `" + TableName + "` (");
            pw.println("\t`" + msqls.get(0).getFieldName() + "` "
                            + msqls.get(0).getDataType() +
                          msqls.get(0).getFormat() + " NOT NULL comment \""
                            + msqls.get(0).getDesc() + "\" ,");
            pw.println("PRIMARY KEY (`" + msqls.get(0).getFieldName() + "`)");
            pw.println(") ENGINE=InnoDB DEFAULT CHARSET=utf8;");
            //System.out.println(msqls.get(1).getFieldName());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //增加字段
    public void AddField(String TableName) throws IOException {

        try (FileWriter fw = new FileWriter(f,true);
             PrintWriter pw = new PrintWriter(fw);) {
            for (int i = 1; i < msqls.size(); i++) {
                pw.println("ALTER TABLE " + TableName);
                pw.println("ADD `" + msqls.get(i).getFieldName() + "` "
                                    + msqls.get(i).getDataType() +
                                     msqls.get(i).getFormat() +  " NULL default "
                                    + msqls.get(i).getInit() + " comment \""
                                    + msqls.get(i).getDesc() + "\" ;");
                //System.out.println(msqls.get(i).getFieldName());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void AddIndex(Map<String, List<String>> index, String tableName) throws IOException {
        try (FileWriter fw = new FileWriter(f,true);
             PrintWriter pw = new PrintWriter(fw);) {

            StringBuffer sb = new StringBuffer();
            sb.append("abs");
            //sb.append("ALTER TABLE " + tableName + " ADD INDEX " + index.keySet() + "(");
            for (Map.Entry<String, List<String>> entry : index.entrySet()) {
                //sb.append(index.get(index.keySet()) + ",");
                sb.replace(0, sb.length(),
                        "ALTER TABLE " + tableName + " ADD INDEX " + entry.getKey() + "(");
                //sb.append("ALTER TABLE " + tableName + "ADD INDEX " + entry.getKey() + "(")
                //pw.print("ALTER TABLE " + tableName + " ADD INDEX " + entry.getKey() + "(");
                for (String str : entry.getValue()) {
                    /*pw.println("ALTER TABLE " + tableName +
                            " ADD INDEX " + entry.getKey() +
                            "(" + entry.getValue() + ");");*/
                    //sb.replace(0, sb.length()-1, str);
                    //sb.deleteCharAt(0);
                    sb.append(str + ",");
                    //sb.replace(sb.length()-1, sb.length()-1,",");
                    //pw.print(str + ",");
                }
                sb.replace(sb.length()-1,sb.length(),");");
                pw.println(sb);

                //pw.println(");");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
