package com.mytest.ProConversion;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OldProgress {
    private static int openPrint;
    private static int endPrint;
    private static String tableName;

    public static void main(String[] args) throws IOException {
        OldProgress oldProgress = new OldProgress();

        List<Msql> msql = new ArrayList<>();
        msql = oldProgress.getData();

        MysqlFile mysqlFile = new MysqlFile(msql);

        Map<String,List<String>> myMap = new HashMap<>();
        myMap = oldProgress.getIndex();
        mysqlFile.CreateTable(tableName);
        mysqlFile.AddField(tableName);
        mysqlFile.AddIndex(myMap, tableName);

    }

    public List<Msql> getData(){
        File file = new File("./src/com/mytest/ProConversion/ld_det.df");
        List<String> list = new ArrayList<String>();
        List<Msql> msqls = new ArrayList<Msql>();
        int count = 0;
        String str = "";
        try (
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
        ){
            List<Integer> flags = new ArrayList<Integer>();
            while((str = br.readLine())!=null){
                if(str.startsWith("ADD FIELD")){
                    flags.add(count);
                }
                list.add(str);
                count++;
            }
            flags.add(getEndPrint(list,"ADD INDEX"));
            openPrint = getOpenPrint(list, "ADD TABLE");
            endPrint = getEndPrint(list, "ADD FIELD");
            //tableName
            String[] names = list.get(openPrint).split("[\\s(\")?]{1,}");
            tableName = names[2];

            for (int i = 0 ; i< flags.size() ; i++){
                Msql msql = new Msql();
                openPrint = flags.get(i);
                endPrint = flags.get(i+1);
                for (int j = openPrint ; j < endPrint-1 ;j++){
                    if(j!=openPrint){
                        String[] split = list.get(j).split("[\\s]{1,}",3);
                        switch (split[1]){
                            case "DESCRIPTION":
                                msql.setDesc(delQuotes(split));break;
                            case "FORMAT":
                                msql.setFormat(FMCor(delQuotes(split)));break;
                            case "INITIAL":
                                if(delQuotes(split)==null || delQuotes(split).equals("")){

                                }else{
                                    msql.setInit(INCor(delQuotes(split)));
                                }break;
                            case "LABEL":
                                if(delQuotes(split)==null || delQuotes(split).equals("")){

                                }else{
                                    msql.setLable(delQuotes(split));
                                }break;
                            case "POSITION":
                                msql.setPosi(delQuotes(split));break;
                            case "MAX-WIDTH":
                                msql.setMaxWidth(delQuotes(split));break;
                            case "VALEXP":
                                msql.setValExp(delQuotes(split));break;
                            case "VALMSG":
                                msql.setValMsg(delQuotes(split));break;
                            case "ORDER":
                                msql.setOrder(delQuotes(split));break;
                            case "MANDATORY":
                                msql.setIsmand(split[1]);break;
                            case "DECIMALS":
                                msql.setDeci(delQuotes(split));break;
                            case "COLUMN-LABEL":
                                msql.setColoLable(delQuotes(split));
                        }
                    }else {
                        String[] split = list.get(openPrint).split("[\\s(\")?]{1,}");
                        //fieldName
                        msql.setFieldName(split[2]);
                        //dataType
                        msql.setDataType(DTCor(split[6]));
                    }
                }
                msqls.add(msql);
            }

        }catch (IOException e){
            // TODO: handle exception
        }finally {
            System.out.println(openPrint+ "and" +endPrint);
            System.out.println(tableName);
            System.out.println("文件是否存在：" + file.exists());
            return msqls;

        }
    }

    //openPrint found
    private int getOpenPrint(List<String> list,String found) {
        for(int i = 0 ; i < list.size() ; i++) {
            if(list.get(i).indexOf(found) != -1) {
                return i;
            }
        }
        return 0;
    }

    //endPrint found
    private int getEndPrint(List<String> list,String found) {
        for(int i = 0 ; i < list.size() ; i++) {
            if(list.get(i).indexOf(found) != -1) {
                return i;
            }
        }
        return 0;
    }

    //去引号
    public static String delQuotes(String[] str){
        StringBuilder strb = new StringBuilder(str[2]);
        char ch = strb.charAt(0);
        if (ch == '\"') {
            strb.deleteCharAt(0);
            strb.deleteCharAt(strb.length() - 1);
        }
        String split2 = new String(strb);
        return split2;
    }

    //数据类型修正
    public static String DTCor(String str) {
        String str1;

        switch (str) {
            case "character":
                str1 = "varchar";break;
            case "logical":
                str1 = "Boolean";break;
            case "date":
                str1 = "timestamp";break;
            default:
                str1 = str;
        }
        return str1;
    }

    //ADD INDEX
    public Map<String,List<String>> getIndex(){
        File file = new File("./src/com/mytest/ProConversion/pt_mstr.df");
        List<String> list = new ArrayList<>();
        Map<String, List<String>> map = new HashMap<>();
        String str = "";
        int count = 0;
        try (
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
        ){
            List<Integer> flags = new ArrayList<Integer>();
            while((str = br.readLine())!=null){
                if(str.startsWith("ADD INDEX")){
                    flags.add(count);
                }
                list.add(str);
                count++;
            }
            flags.add(list.size());
            System.out.println(flags.size());
            for (int i = 0 ;i < flags.size()-1 ; i++){
                List<String> value = new ArrayList<>();
                String key = "";
                openPrint = flags.get(i);
                endPrint = flags.get(i+1);
                for (int j = openPrint; j < endPrint-1 ; j++){
                    if(j != openPrint){
                        String[] split = list.get(j).split("[\\s]{1,}");
                        if (split.length>=3){
                            if (split[2].matches("[(\")?A-Z(_)?(\")?]{1,}")){

                            }else {
                                value.add(delQuotes(split));
                            }
                        }
                    }else{
                        String[] split = list.get(openPrint).split("[\\s(\")?]{1,}");
                        key = split[2];
                    }
                }
                System.out.println("key="+key + "   value="+ value);
                map.put(key,value);
            }
            System.out.println(map.size());
            for (Map.Entry<String,List<String>> entry : map.entrySet()
            ) {
                System.out.println("key="+entry.getKey()+" and value="+entry.getValue());
            }
        }catch (IOException e){
            // TODO: handle exception
        }finally {
            return map;
        }
    }

    //数据替换
    public static String FMCor(String str1) {

        String str2;

        switch (str1) {
            case "x(18)":
                str2 = "(18)";
                break;
            case "x(24)":
                str2 = "(24)";
                break;
            case "x(2)":
                str2 = "(2)";
                break;
            case "x(4)":
                str2 = "(4)";
                break;
            case ">>>>9.9999<<<<":
                str2 = "(5,5)";
                break;
            case "x(1)":
                str2 = "(1)";
                break;
            case "yes/no":
                str2 = "";
                break;
            case "X(18)":
                str2 = "(18)";
                break;
            case "X(12)":
                str2 = "(12)";
                break;
            case "x(8)":
                str2 = "(8)";
                break;
            case "xx":
                str2 = "(2)";
                break;
            case ">>>>9":
                str2 = "(5)";
                break;
            case ">>,>>9.99":
                str2 = "(5,2)";
                break;
            case "->>,>>9.99":
                str2 = "(5,2)";
                break;
            case "->>,>>9.99<<<<":
                str2 = "(6,6)";
                break;
            case "->,>>>,>>9.9<<<<<<<<":
                str2 = "(9,9)";
                break;
            case ">>,>>>,>>9":
                str2 = "(8)";
                break;
            case ">>>,>>9":
                str2 = "(6)";
                break;
            case ">>9":
                str2 = "(3)";
                break;
            case ">>,>>9.9<<<":
                str2 = "(5,4)";
                break;
            case "-9":
                str2 = "(9)";
                break;
            case ">>9.9":
                str2 = "(3,1)";
                break;
            case ">>>>,>>>,>>9.99<<<":
                str2 = "(10,5)";
                break;
            case ">>>>>>>>>>>>>>>>>>>>>>>>>>>9.9<<<<<<<<<":
                str2 = "(28,9)";
                break;
            case "99/99/99":
                str2 = "";
                break;
            case "->,>>>,>>>":
                str2 = "(7)";
                break;
            case ">>,>>>,>>9.9<<<<<<<<":
                str2 = "(8,8)";
                break;
            case ">>>,>>>,>>9.99":
                str2 = "(9,2)";
                break;
            case "->>>>>9":
                str2 = "(6)";
                break;
            case ">>9.9<%":
                str2 = "(3,1)";
                break;
            case "->>>,>>9.999":
                str2 = "(6,3)";
                break;
            case "x(3)":
                str2 = "(3)";
                break;
            case ">>9.99%":
                str2 = "(3,2)";
                break;
            case ">>>,>>9.9":
                str2 = "(6,1)";
                break;
            case ">>>,>>9.999<<<<<<":
                str2 = "(6,6)";
                break;
            case "->>>9":
                str2 = "(4)";
                break;
            case "x(10)":
                str2 = "(10)";
                break;
            case "X(2)":
                str2 = "(2)";
                break;
            case "x(12)":
                str2 = "(12)";
                break;
            case "X(8)":
                str2 = "(8)";
                break;


            default:
                str2 = str1;

        }
        return str2;
    }

    //数据类型修正
    public static String INCor(String str4) {
        String str3;

        switch (str4) {
            case "PC":
                str3 = "'"+"PC"+"'";
                break;
            case "yes":
                str3 = "true";
                break;
            case "no":
                str3 = "false";
                break;
            case "yes or no":
                str3 = "true or false";
                break;
            case "today":
                str3 = "CURRENT_TIMESTAMP";
                break;
            case "?":
                str3 = "null";
                break;
            case "C":
                str3 = "'"+"C"+"'";
                break;
            case "POQ":
                str3 = "'"+"POQ"+"'";
                break;
            case "100":
                str3 = "'" + "100" + "'";break;
            case "1":
                str3 = "'" + "1" + "'";break;
            default:
                str3 = str4;

        }
        return str3;
    }
}
