DROP TABLE IF EXISTS `ld_det`;
CREATE TABLE `ld_det` (
	`ld_loc` varchar(8) NOT NULL comment "The code for the stocking location." ,
PRIMARY KEY (`ld_loc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE ld_det
ADD `ld_part` varchar(18) NULL default null comment "The code identifying the item that is stored at this location." ;
ALTER TABLE ld_det
ADD `ld_date` timestamp NULL default CURRENT_TIMESTAMP comment "The date when this location detail record was created." ;
ALTER TABLE ld_det
ADD `ld_qty_oh` decimal(9,9) NULL default 0 comment "The quantity of items currently stored at this location." ;
ALTER TABLE ld_det
ADD `ld_lot` varchar(18) NULL default null comment "The lot/serial number of the items stored at this location." ;
ALTER TABLE ld_det
ADD `ld_ref` varchar(8) NULL default null comment "The bin, skid, roll or pallet number." ;
ALTER TABLE ld_det
ADD `ld_cnt_date` timestamp NULL default null comment "The date when this location detail was last counted." ;
ALTER TABLE ld_det
ADD `ld_assay` decimal(3,2) NULL default 0 comment "The percent solution for items with this lot/serial number." ;
ALTER TABLE ld_det
ADD `ld_expire` timestamp NULL default null comment "The date on which this lot/serial will expire." ;
ALTER TABLE ld_det
ADD `ld_user1` varchar(8) NULL default null comment "User field #1." ;
ALTER TABLE ld_det
ADD `ld_user2` varchar(8) NULL default null comment "User field #2." ;
ALTER TABLE ld_det
ADD `ld_site` varchar(8) NULL default null comment "The site for this location detail record." ;
ALTER TABLE ld_det
ADD `ld_status` varchar(8) NULL default null comment "The inventory status of stock in this location detail record." ;
ALTER TABLE ld_det
ADD `ld_qty_all` decimal(9,9) NULL default 0 comment "The quantity allocated from this location detail." ;
ALTER TABLE ld_det
ADD `ld_grade` varchar(2) NULL default null comment "The user defined grade of stock in this location detail record." ;
ALTER TABLE ld_det
ADD `ld_qty_frz` decimal(9,9) NULL default 0 comment "The frozen on hand balance." ;
ALTER TABLE ld_det
ADD `ld_date_frz` timestamp NULL default null comment "The date the frozen on hand balance was last updated." ;
ALTER TABLE ld_det
ADD `ld_vd_lot` varchar(18) NULL default null comment "The original supplier's lot/serial number when received." ;
ALTER TABLE ld_det
ADD `ld_cmtindx` integer>>>>>>>9 NULL default 0 comment "A pointer to the comments associated with this record." ;
ALTER TABLE ld_det
ADD `ld_work` decimal->>>,>>>,>>9.9<<<<<<<<< NULL default 0 comment "Used as a work variable." ;
ALTER TABLE ld_det
ADD `ld__chr01` varchar(8) NULL default null comment "User custom character field #1." ;
ALTER TABLE ld_det
ADD `ld__chr02` varchar(8) NULL default null comment "User custom character field #2." ;
ALTER TABLE ld_det
ADD `ld__chr03` varchar(8) NULL default null comment "User custom character field #3." ;
ALTER TABLE ld_det
ADD `ld__chr04` varchar(8) NULL default null comment "User custom character field #4." ;
ALTER TABLE ld_det
ADD `ld__chr05` varchar(8) NULL default null comment "User custom character field #5." ;
ALTER TABLE ld_det
ADD `ld__dte01` timestamp NULL default null comment "User custom date field #1." ;
ALTER TABLE ld_det
ADD `ld__dte02` timestamp NULL default null comment "User custom date field #2." ;
ALTER TABLE ld_det
ADD `ld__dec01` decimal(9,2) NULL default 0 comment "User custom decimal field #1." ;
ALTER TABLE ld_det
ADD `ld__dec02` decimal(9,2) NULL default 0 comment "User custom decimal field #2." ;
ALTER TABLE ld_det
ADD `ld__log01` Boolean NULL default false comment "User custom logical field #1." ;
ALTER TABLE ld_det
ADD `ld_cost` decimal(10,5) NULL default 0 comment "Not used." ;
ALTER TABLE ld_det
ADD `ld_rev` varchar(4) NULL default null comment "The revision level level of stock in this location detail record." ;
ALTER TABLE ld_det
ADD `ld_cust_consign_qty` decimal->>,>>>,>>9.9<<<<<<<<< NULL default 0 comment "The quantity of customer consignment inventory stored at this location." ;
ALTER TABLE ld_det
ADD `ld_supp_consign_qty` decimal->>,>>>,>>9.9<<<<<<<<< NULL default 0 comment "The quantity of supplier consignment inventory stored at this location." ;
ALTER TABLE ld_det
ADD `ld_domain` varchar(8) NULL default null comment "The business domain for this data." ;
ALTER TABLE ld_det
ADD `oid_ld_det` decimal(28,9) NULL default 0 comment "Unique application generated record identifier." ;
ALTER TABLE ld_det ADD INDEX pt_routing(pt_domain,pt_routing,pt_part);
ALTER TABLE ld_det ADD INDEX pt_network(pt_domain,pt_network,pt_part);
ALTER TABLE ld_det ADD INDEX pt_model(pt_domain,pt_model);
ALTER TABLE ld_det ADD INDEX pt_bom_code(pt_domain,pt_bom_code,pt_part);
ALTER TABLE ld_det ADD INDEX pt_svc_group(pt_domain,pt_svc_group);
ALTER TABLE ld_det ADD INDEX pt_part_type(pt_domain,pt_part_type,pt_part);
ALTER TABLE ld_det ADD INDEX pt_pm_mrp(pt_domain,pt_pm_mrp,pt_part);
ALTER TABLE ld_det ADD INDEX pt_user3(pt_domain,pt_user3,pt_part);
ALTER TABLE ld_det ADD INDEX pt_part(pt_domain,pt_part);
ALTER TABLE ld_det ADD INDEX pt_group(pt_domain,pt_group,pt_part);
ALTER TABLE ld_det ADD INDEX pt_prod_part(pt_domain,pt_prod_line,pt_part);
ALTER TABLE ld_det ADD INDEX pt_pvm_bom(pt_domain,pt_pvm_bom,pt_part);
ALTER TABLE ld_det ADD INDEX pt_desc(pt_domain,pt_desc1,pt_desc2,pt_part);
ALTER TABLE ld_det ADD INDEX pt_ll_mrp_pt(pt_domain,pt_ll_code,pt_mrp,pt_part);
