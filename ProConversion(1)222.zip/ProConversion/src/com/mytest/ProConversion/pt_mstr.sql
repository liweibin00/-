DROP TABLE IF EXISTS `pt_mstr`;
CREATE TABLE `pt_mstr` (
	`pt_part` varchar(18) NOT NULL comment "The unique code used to identify an item or product." ,
PRIMARY KEY (`pt_part`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE pt_mstr
ADD `pt_desc1` varchar(24) NULL default null comment "The first description line for this item." ;
ALTER TABLE pt_mstr
ADD `pt_desc2` varchar(24) NULL default null comment "The second description line for this item." ;
ALTER TABLE pt_mstr
ADD `pt_um` varchar(2) NULL default 'PC' comment "The stocking unit of measure for this item." ;
ALTER TABLE pt_mstr
ADD `pt__qad13` varchar(4) NULL default null comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad12` decimal(5,5) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_draw` varchar(18) NULL default null comment "The code which identifies the drawing for this item." ;
ALTER TABLE pt_mstr
ADD `pt_prod_line` varchar(4) NULL default null comment "The product line to which this item belongs." ;
ALTER TABLE pt_mstr
ADD `pt_group` varchar(8) NULL default null comment "The product group for this item used for reporting purposes." ;
ALTER TABLE pt_mstr
ADD `pt_part_type` varchar(8) NULL default null comment "A code used to group items with similar characteristics." ;
ALTER TABLE pt_mstr
ADD `pt_status` varchar(8) NULL default null comment "A user defined engineering status for this item:  Active, Inactive,..." ;
ALTER TABLE pt_mstr
ADD `pt_abc` varchar(1) NULL default null comment "The ABC classification for a part. (Can be calculated.)." ;
ALTER TABLE pt_mstr
ADD `pt_iss_pol` Boolean NULL default true comment "A flag specifying if this item will be printed on pick lists." ;
ALTER TABLE pt_mstr
ADD `pt_phantom` Boolean NULL default false comment "A flag specifying that this item is a phantom." ;
ALTER TABLE pt_mstr
ADD `pt_loc` varchar(8) NULL default null comment "The code identifying the default location where this item is stocked." ;
ALTER TABLE pt_mstr
ADD `pt__qad01` decimal(9,9) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad02` decimal(9,9) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_abc_amt` decimal(9,9) NULL default 0 comment "Field used internally for ABC classification." ;
ALTER TABLE pt_mstr
ADD `pt__qad03` decimal(6,3) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad04` decimal(6,3) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_avg_int` integer(3) NULL default 90 comment "The number of days used as the interval for calculating averages." ;
ALTER TABLE pt_mstr
ADD `pt__qad05` timestamp NULL default CURRENT_TIMESTAMP comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_cyc_int` integer(3) NULL default 120 comment "The number of calendar days between cycle counts for this item." ;
ALTER TABLE pt_mstr
ADD `pt__qad06` timestamp NULL default null comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad07` timestamp NULL default null comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad08` timestamp NULL default null comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_ms` Boolean NULL default true comment "A flag specifying if this item is to appear on the master schedule." ;
ALTER TABLE pt_mstr
ADD `pt_plan_ord` Boolean NULL default true comment "A flag specifying if MRP is to create planned orders for this item." ;
ALTER TABLE pt_mstr
ADD `pt_mrp` Boolean NULL default false comment "A flag indicating if this item is to be planned by net change MRP." ;
ALTER TABLE pt_mstr
ADD `pt_ord_pol` varchar(3) NULL default 'POQ' comment "A code specifying the order policy to apply during MRP." ;
ALTER TABLE pt_mstr
ADD `pt_ord_qty` decimal(8) NULL default 0 comment "The order quantity to be used by MRP for order policy FOQ." ;
ALTER TABLE pt_mstr
ADD `pt_ord_per` integer(3) NULL default 7 comment "The number of days of demand used by MRP for order policy POQ." ;
ALTER TABLE pt_mstr
ADD `pt_sfty_stk` decimal(8) NULL default 0 comment "The minimum quantity to be left in inventory." ;
ALTER TABLE pt_mstr
ADD `pt_sfty_time` decimal(3) NULL default 0 comment "The number of days between due dates and need dates." ;
ALTER TABLE pt_mstr
ADD `pt_rop` decimal(6) NULL default 0 comment "The quantity on hand that triggers action on the reorder report." ;
ALTER TABLE pt_mstr
ADD `pt_buyer` varchar(8) NULL default null comment "The person responsible for planning this item." ;
ALTER TABLE pt_mstr
ADD `pt_vend` varchar(8) NULL default null comment "The address code of the primary supplier for this item." ;
ALTER TABLE pt_mstr
ADD `pt__qad09` decimal(9,9) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_pm_code` varchar(1) NULL default null comment "The purchase / manufacture code for this item (P, M, L, R, C, F, D)." ;
ALTER TABLE pt_mstr
ADD `pt_mfg_lead` decimal(3) NULL default 0 comment "The number of days required to manufacture this item." ;
ALTER TABLE pt_mstr
ADD `pt_pur_lead` integer(3) NULL default 0 comment "The number of days required to complete a purchase order for this item" ;
ALTER TABLE pt_mstr
ADD `pt_insp_rqd` Boolean NULL default false comment "A flag specifying a purchased item requires incoming inspection." ;
ALTER TABLE pt_mstr
ADD `pt_insp_lead` integer(3) NULL default 0 comment "The number of days to add to purchase lead time for inspection." ;
ALTER TABLE pt_mstr
ADD `pt_cum_lead` integer(3) NULL default 0 comment "The critical path lead time for this item." ;
ALTER TABLE pt_mstr
ADD `pt_ord_min` decimal(8) NULL default 0 comment "The minimum order quantity for this item." ;
ALTER TABLE pt_mstr
ADD `pt_ord_max` decimal(8) NULL default 0 comment "The maximum order quantity for this item." ;
ALTER TABLE pt_mstr
ADD `pt_ord_mult` decimal(8) NULL default 0 comment "The order quantity multiple used for lot sizing in MRP." ;
ALTER TABLE pt_mstr
ADD `pt_yield_pct` decimal(3,2) NULL default '100' comment "The approximate percentage of orders which will be acceptable." ;
ALTER TABLE pt_mstr
ADD `pt__qad16` decimal(6,1) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_setup` decimal(6,6) NULL default 0 comment "The standard setup hours required for one lot of this item." ;
ALTER TABLE pt_mstr
ADD `pt_setup_ll` decimal(6,6) NULL default 0 comment "The accumulated setup time from all lower level components." ;
ALTER TABLE pt_mstr
ADD `pt_run_ll` decimal(6,6) NULL default 0 comment "The accumulated run time from all lower level component run times." ;
ALTER TABLE pt_mstr
ADD `pt_run` decimal(6,6) NULL default 0 comment "The standard run time hours required to make one unit of this item." ;
ALTER TABLE pt_mstr
ADD `pt_price` decimal(10,5) NULL default 0 comment "The normal selling price for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xmtl_tl` decimal(10,5) NULL default 0 comment "Not used.  The current cost of material added at this level." ;
ALTER TABLE pt_mstr
ADD `pt_xlbr_tl` decimal(10,5) NULL default 0 comment "Not used.  The current cost of labor added at this level." ;
ALTER TABLE pt_mstr
ADD `pt_xbdn_tl` decimal(10,5) NULL default 0 comment "Not used.  The current cost of burden added at this level." ;
ALTER TABLE pt_mstr
ADD `pt_xsub_tl` decimal(10,5) NULL default 0 comment "Not used.  The current cost of subcontracting added at this level." ;
ALTER TABLE pt_mstr
ADD `pt_xmtl_ll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated current cost of material from all lower level" ;
ALTER TABLE pt_mstr
ADD `pt_xlbr_ll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated current cost of labor from all lower level co" ;
ALTER TABLE pt_mstr
ADD `pt_xbdn_ll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated burden cost from all lower level components." ;
ALTER TABLE pt_mstr
ADD `pt_xsub_ll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated current cost of subcontracting for all lower " ;
ALTER TABLE pt_mstr
ADD `pt_xtot_cur` decimal(10,5) NULL default 0 comment "Not used.  The sum of current costs for this level and all lower levels." ;
ALTER TABLE pt_mstr
ADD `pt_cur_date` timestamp NULL default null comment "The date of the last current cost update." ;
ALTER TABLE pt_mstr
ADD `pt_xmtl_stdtl` decimal(10,5) NULL default 0 comment "Not used.  The standard material cost for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xlbr_stdtl` decimal(10,5) NULL default 0 comment "Not used.  The standard cost of labor for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xbdn_stdtl` decimal(10,5) NULL default 0 comment "Not used.  The standard burden cost for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xsub_stdtl` decimal(10,5) NULL default 0 comment "Not used.  The standard cost of subcontracting for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xtot_std` decimal(10,5) NULL default 0 comment "Not used.  The sum of this level and lower level standard costs for this" ;
ALTER TABLE pt_mstr
ADD `pt_std_date` timestamp NULL default null comment "The date of the last standard cost update." ;
ALTER TABLE pt_mstr
ADD `pt_ll_code` integer(6) NULL default 0 comment "A code used by MRP to record the lowest level usage of the item." ;
ALTER TABLE pt_mstr
ADD `pt_abc_qty` decimal(9,9) NULL default 0 comment "Field used internally for ABC classification." ;
ALTER TABLE pt_mstr
ADD `pt__qad10` decimal(9,9) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad11` decimal(9,9) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_routing` varchar(18) NULL default null comment "Identifies the default routing to use for this item." ;
ALTER TABLE pt_mstr
ADD `pt_lot_ser` varchar(1) NULL default null comment "A flag indicating if lot/serial numbers are required for this item." ;
ALTER TABLE pt_mstr
ADD `pt_timefence` integer(4) NULL default 0 comment "The number of days within which no planned orders are generated." ;
ALTER TABLE pt_mstr
ADD `pt_xmtl_stdll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated standard cost of material from all lower leve" ;
ALTER TABLE pt_mstr
ADD `pt_xlbr_stdll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated standard cost of labor from all lower levels." ;
ALTER TABLE pt_mstr
ADD `pt_xbdn_stdll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated standard cost of burden from all lower levels" ;
ALTER TABLE pt_mstr
ADD `pt_xsub_stdll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated standard cost of subcontracting for all lower" ;
ALTER TABLE pt_mstr
ADD `pt_rev` varchar(4) NULL default null comment "The last effective revision level of this item." ;
ALTER TABLE pt_mstr
ADD `pt_last_eco` timestamp NULL default null comment "The date of the last engineering change order for this item." ;
ALTER TABLE pt_mstr
ADD `pt__qad15` Boolean NULL default false comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad17` Boolean NULL default true comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_qc_lead` integer(3) NULL default 0 comment "Not used.  Originally for the quality control lead time." ;
ALTER TABLE pt_mstr
ADD `pt_auto_lot` Boolean NULL default false comment "A flag indicating if lot numbers are assigned automatically." ;
ALTER TABLE pt_mstr
ADD `pt_assay` decimal(3,2) NULL default 0 comment "The normal assay percentage (percent solution) of an item." ;
ALTER TABLE pt_mstr
ADD `pt_batch` decimal(8,8) NULL default '1' comment "The normal batch quantity to be used for BOM and routings." ;
ALTER TABLE pt_mstr
ADD `pt__qad14` timestamp NULL default null comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_user3` varchar(8) NULL default null comment "Not used.  Field available for user definition and use." ;
ALTER TABLE pt_mstr
ADD `pt_user1` varchar(8) NULL default null comment "User field #1." ;
ALTER TABLE pt_mstr
ADD `pt_user2` varchar(8) NULL default null comment "User field #2." ;
ALTER TABLE pt_mstr
ADD `pt_net_wt` decimal(6,6) NULL default 0 comment "The net weight of each unit of this item." ;
ALTER TABLE pt_mstr
ADD `pt_net_wt_um` varchar(2) NULL default null comment "The unit of measure for the item net weight." ;
ALTER TABLE pt_mstr
ADD `pt_size` decimal(5,2) NULL default 0 comment "A user defined code indicating the physical dimensions of this item." ;
ALTER TABLE pt_mstr
ADD `pt_size_um` varchar(2) NULL default null comment "The unit of measure for the item size." ;
ALTER TABLE pt_mstr
ADD `pt_taxable` Boolean NULL default true comment "A flag indicating this item is taxable." ;
ALTER TABLE pt_mstr
ADD `pt_taxc` varchar(3) NULL default null comment "The Tax Class Code for this item." ;
ALTER TABLE pt_mstr
ADD `pt_rollup` Boolean NULL default false comment "A flag indicating that a BOM or routing roll-up is needed for this item." ;
ALTER TABLE pt_mstr
ADD `pt_xovh_ll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated current cost of overhead from all lower level" ;
ALTER TABLE pt_mstr
ADD `pt_xovh_tl` decimal(10,5) NULL default 0 comment "Not used.  The current cost of overhead added at this level." ;
ALTER TABLE pt_mstr
ADD `pt_xovh_stdll` decimal(10,5) NULL default 0 comment "Not used.  The accumulated standard overhead cost from all lower levels." ;
ALTER TABLE pt_mstr
ADD `pt_xovh_stdtl` decimal(10,5) NULL default 0 comment "Not used.  The standard overhead cost for this item." ;
ALTER TABLE pt_mstr
ADD `pt_site` varchar(8) NULL default null comment "The default site for this item." ;
ALTER TABLE pt_mstr
ADD `pt_shelflife` integer(7) NULL default 0 comment "The default shelf life for this item." ;
ALTER TABLE pt_mstr
ADD `pt_critical` Boolean NULL default false comment "A flag classifying this item as critical when used on a work order." ;
ALTER TABLE pt_mstr
ADD `pt_sngl_lot` Boolean NULL default false comment "A flag indicating that stock must be allocated from a single batch." ;
ALTER TABLE pt_mstr
ADD `pt_upc` varchar(12) NULL default null comment "The universal product code for this item." ;
ALTER TABLE pt_mstr
ADD `pt_hazard` varchar(8) NULL default null comment "A hazardous materials code for this item." ;
ALTER TABLE pt_mstr
ADD `pt_added` timestamp NULL default CURRENT_TIMESTAMP comment "The date this item was added to the system." ;
ALTER TABLE pt_mstr
ADD `pt__chr01` varchar(8) NULL default null comment "User custom character field #1." ;
ALTER TABLE pt_mstr
ADD `pt__chr02` varchar(8) NULL default null comment "User custom character field #2." ;
ALTER TABLE pt_mstr
ADD `pt__chr03` varchar(8) NULL default null comment "User custom character field #3." ;
ALTER TABLE pt_mstr
ADD `pt__chr04` varchar(8) NULL default null comment "User custom character field #4." ;
ALTER TABLE pt_mstr
ADD `pt__chr05` varchar(8) NULL default null comment "User custom character field #5." ;
ALTER TABLE pt_mstr
ADD `pt__chr06` varchar(8) NULL default null comment "User custom character field #6." ;
ALTER TABLE pt_mstr
ADD `pt__chr07` varchar(8) NULL default null comment "User custom character field #7." ;
ALTER TABLE pt_mstr
ADD `pt__chr08` varchar(8) NULL default null comment "User custom character field #8." ;
ALTER TABLE pt_mstr
ADD `pt__chr09` varchar(8) NULL default null comment "User custom character field #9." ;
ALTER TABLE pt_mstr
ADD `pt__chr10` varchar(8) NULL default null comment "User custom character field #10." ;
ALTER TABLE pt_mstr
ADD `pt__dte01` timestamp NULL default null comment "User custom date field #1." ;
ALTER TABLE pt_mstr
ADD `pt__dte02` timestamp NULL default null comment "User custom date field #2." ;
ALTER TABLE pt_mstr
ADD `pt__dec01` decimal(9,2) NULL default 0 comment "User custom decimal field #1." ;
ALTER TABLE pt_mstr
ADD `pt__dec02` decimal(9,2) NULL default 0 comment "User custom decimal field #2." ;
ALTER TABLE pt_mstr
ADD `pt__log01` Boolean NULL default false comment "User custom logical field #1." ;
ALTER TABLE pt_mstr
ADD `pt__log02` Boolean NULL default false comment "User custom logical field #2." ;
ALTER TABLE pt_mstr
ADD `pt__qad18` decimal(10,5) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad21` decimal(10,5) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad19` decimal(10,5) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt__qad20` decimal(10,5) NULL default 0 comment "Not used, reserved for qad use." ;
ALTER TABLE pt_mstr
ADD `pt_length` decimal(5,2) NULL default 0 comment "The length of this item." ;
ALTER TABLE pt_mstr
ADD `pt_height` decimal(5,2) NULL default 0 comment "The height of this item." ;
ALTER TABLE pt_mstr
ADD `pt_width` decimal(5,2) NULL default 0 comment "The width of this item." ;
ALTER TABLE pt_mstr
ADD `pt_dim_um` varchar(2) NULL default null comment "The dimensions unit of measure for this item." ;
ALTER TABLE pt_mstr
ADD `pt_pkg_code` varchar(18) NULL default null comment "A code, item number or description of packaging requirements." ;
ALTER TABLE pt_mstr
ADD `pt_network` varchar(18) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_fr_class` varchar(8) NULL default null comment "A code used for calculating freight charges." ;
ALTER TABLE pt_mstr
ADD `pt_spec_hdlg` varchar(8) NULL default null comment "A code indicating special handling requirements." ;
ALTER TABLE pt_mstr
ADD `pt_bom_code` varchar(18) NULL default null comment "The bill of material/formula to use for this item." ;
ALTER TABLE pt_mstr
ADD `pt_loc_type` varchar(8) NULL default null comment "A code specifying special location requirements for this item." ;
ALTER TABLE pt_mstr
ADD `pt_transtype` varchar(8) NULL default null comment "A code specifying specific transportation requirements for this item." ;
ALTER TABLE pt_mstr
ADD `pt_warr_cd` varchar(8) NULL default null comment "Warranty Code from the sv_mstr file (warranty)" ;
ALTER TABLE pt_mstr
ADD `pt_pvm_days` integer(5) NULL default 0 comment "Days between preventative maintenance periods for this part" ;
ALTER TABLE pt_mstr
ADD `pt_isb` Boolean NULL default false comment "Should this part be transfer to installed base when shipped" ;
ALTER TABLE pt_mstr
ADD `pt_mttr` decimal(5,2) NULL default 0 comment "Mean time to repair in hours" ;
ALTER TABLE pt_mstr
ADD `pt_mtbf` decimal(5,2) NULL default 0 comment "Mean time between failures" ;
ALTER TABLE pt_mstr
ADD `pt_svc_type` varchar(2) NULL default null comment "Service Type of this part - a user-definable field for reference only" ;
ALTER TABLE pt_mstr
ADD `pt_svc_group` varchar(8) NULL default null comment "Service group ...Generalized Codes" ;
ALTER TABLE pt_mstr
ADD `pt_ven_warr` Boolean NULL default false comment "Does this part have a supplier warranty." ;
ALTER TABLE pt_mstr
ADD `pt_fru` Boolean NULL default false comment "Field replaceable unit." ;
ALTER TABLE pt_mstr
ADD `pt_mfg_mttr` decimal(5,2) NULL default 0 comment "Manufacturers MTTR." ;
ALTER TABLE pt_mstr
ADD `pt_mfg_mtbf` decimal(5,2) NULL default 0 comment "manufacturers stated MTBF" ;
ALTER TABLE pt_mstr
ADD `pt_sttr` decimal(5,2) NULL default 0 comment "Standard time to repair." ;
ALTER TABLE pt_mstr
ADD `pt_origin` varchar(12) NULL default null comment "Country where part was manufactured." ;
ALTER TABLE pt_mstr
ADD `pt_tariff` varchar(8) NULL default null comment "Tariff Number." ;
ALTER TABLE pt_mstr
ADD `pt_sys_type` varchar(2) NULL default null comment "Item Type" ;
ALTER TABLE pt_mstr
ADD `pt_inst_call` Boolean NULL default false comment "Schedule installation call." ;
ALTER TABLE pt_mstr
ADD `pt_cover` varchar(1) NULL default 'C' comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_unit_isb` Boolean NULL default false comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_article` varchar(18) NULL default null comment "Article Number for waybills etc." ;
ALTER TABLE pt_mstr
ADD `pt_ll_drp` integer(6) NULL default 0 comment "The low level value for this item in the distribution network." ;
ALTER TABLE pt_mstr
ADD `pt_po_site` varchar(8) NULL default null comment "The default purchasing site for this item." ;
ALTER TABLE pt_mstr
ADD `pt_ship_wt` decimal(6,6) NULL default 0 comment "The ship weight of each unit of this item." ;
ALTER TABLE pt_mstr
ADD `pt_ship_wt_um` varchar(2) NULL default null comment "The unit of measure for the item ship weight." ;
ALTER TABLE pt_mstr
ADD `pt_userid` varchar(8) NULL default null comment "The Userid of the last user to access this record." ;
ALTER TABLE pt_mstr
ADD `pt_mod_date` timestamp NULL default null comment "Date the record was last modified." ;
ALTER TABLE pt_mstr
ADD `pt__qad26` Boolean NULL default false comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_comm_code` varchar(8) NULL default null comment "The commodity code identifier used for centralized purchasing." ;
ALTER TABLE pt_mstr
ADD `pt__qad22` Boolean NULL default false comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_dea` Boolean NULL default false comment "Identifies items strictly controlled by the FDA." ;
ALTER TABLE pt_mstr
ADD `pt_formula` Boolean NULL default false comment "Restricts items to use formula maintenance." ;
ALTER TABLE pt_mstr
ADD `pt__qad23` integer(3) NULL default 0 comment "null" ;
ALTER TABLE pt_mstr
ADD `pt__qad24` integer(3) NULL default 0 comment "null" ;
ALTER TABLE pt_mstr
ADD `pt__qad25` integer(3) NULL default 0 comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_obs_date` timestamp NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_pvm_bom` varchar(18) NULL default null comment "preventative maintenance bom code" ;
ALTER TABLE pt_mstr
ADD `pt_pvm_route` varchar(18) NULL default null comment "preventative maintenance routing" ;
ALTER TABLE pt_mstr
ADD `pt_pvm_um` varchar(2) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_rp_bom` varchar(18) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_rp_route` varchar(18) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_rp_vendor` varchar(8) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_rctpo_status` varchar(8) NULL default null comment "The status to be used at PO receipt for cageless quarantine." ;
ALTER TABLE pt_mstr
ADD `pt_rollup_id` varchar(8) NULL default null comment "The user id of the process rolling up this record." ;
ALTER TABLE pt_mstr
ADD `pt_spec_grav` decimal(5,4) NULL default 0 comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_joint_type` varchar(1) NULL default null comment "Joint Product Type: 1-Coproduct, 2-Byproduct, 3-Recycled, 4-Waste." ;
ALTER TABLE pt_mstr
ADD `pt_mfg_pct` decimal(3,1) NULL default 0 comment "The percent of planned orders which should be treated as manufactured." ;
ALTER TABLE pt_mstr
ADD `pt_pur_pct` decimal(3,1) NULL default 0 comment "The percent of planned orders which should be treated as purchased." ;
ALTER TABLE pt_mstr
ADD `pt_drp_pct` decimal(3,1) NULL default 0 comment "The percent of planned orders which should be supplied through DRP." ;
ALTER TABLE pt_mstr
ADD `pt_pou_code` varchar(18) NULL default null comment "The pointer into the appropriate point of use network for backflush." ;
ALTER TABLE pt_mstr
ADD `pt_wks_avg` decimal(3,1) NULL default 0 comment "The average number of weeks of forecasted requirements to hold." ;
ALTER TABLE pt_mstr
ADD `pt_wks_max` decimal(3,1) NULL default 0 comment "The maximum number of weeks of forecasted requirements to hold." ;
ALTER TABLE pt_mstr
ADD `pt_wks_min` decimal(3,1) NULL default 0 comment "The minimum number of weeks of forecasted requirements to hold." ;
ALTER TABLE pt_mstr
ADD `pt_pick_logic` integer(9) NULL default 0 comment "The picking logic to use for this item (non-zero overrides icc_ctrl)." ;
ALTER TABLE pt_mstr
ADD `pt_fiscal_class` varchar(18) NULL default null comment "Fiscal class to which this item belongs (for tax reporting)." ;
ALTER TABLE pt_mstr
ADD `pt_dsgn_grp` varchar(8) NULL default null comment "The engineering group responsible for this item." ;
ALTER TABLE pt_mstr
ADD `pt_drwg_loc` varchar(8) NULL default null comment "The code identifying the location where this drawing is stored." ;
ALTER TABLE pt_mstr
ADD `pt_ecn_rev` varchar(4) NULL default null comment "The last released engineering revision level of this item." ;
ALTER TABLE pt_mstr
ADD `pt_drwg_size` varchar(2) NULL default null comment "The unit of measure for the item size." ;
ALTER TABLE pt_mstr
ADD `pt_model` varchar(18) NULL default null comment "Model" ;
ALTER TABLE pt_mstr
ADD `pt_repairable` Boolean NULL default false comment "is this a repairable part" ;
ALTER TABLE pt_mstr
ADD `pt_rctwo_status` varchar(8) NULL default null comment "The status to be used at PO receipt for cageless quarantine" ;
ALTER TABLE pt_mstr
ADD `pt_rctpo_active` Boolean NULL default false comment "Flag indicating whether purchase order receipt status is active." ;
ALTER TABLE pt_mstr
ADD `pt_lot_grp` varchar(8) NULL default null comment "null" ;
ALTER TABLE pt_mstr
ADD `pt_rctwo_active` Boolean NULL default false comment "Flag indicating whether work order receipt status is active." ;
ALTER TABLE pt_mstr
ADD `pt_break_cat` varchar(18) NULL default null comment "Used to combine item quantities when determining Pricing" ;
ALTER TABLE pt_mstr
ADD `pt_fsc_code` varchar(8) NULL default null comment "Service category" ;
ALTER TABLE pt_mstr
ADD `pt_trace_active` Boolean NULL default false comment "Tracing is enabled for this item" ;
ALTER TABLE pt_mstr
ADD `pt_trace_detail` Boolean NULL default false comment "Trace detail exists for this item (no need to transalate)" ;
ALTER TABLE pt_mstr
ADD `pt_pm_mrp` Boolean NULL default false comment "A flag indicating this part's preventive mainenance scheduling needs replanning by MRP." ;
ALTER TABLE pt_mstr
ADD `pt_ins_call_type` varchar(8) NULL default null comment "Type of call for this item's installation" ;
ALTER TABLE pt_mstr
ADD `pt_ins_bom` varchar(18) NULL default null comment "Bill of Material to use for this part's installation calls." ;
ALTER TABLE pt_mstr
ADD `pt_ins_route` varchar(18) NULL default null comment "Routing associated with this item's installation." ;
ALTER TABLE pt_mstr
ADD `pt_promo` varchar(10) NULL default null comment "The promotion group to which the item belongs. Used by APM" ;
ALTER TABLE pt_mstr
ADD `pt_meter_interval` decimal(10,5) NULL default 0 comment "For Service activities, this is the increment between scheduled service activity for this part (i.e., every 30,000 miles)" ;
ALTER TABLE pt_mstr
ADD `pt_meter_um` varchar(2) NULL default null comment "Unit of Measure for the associated service interval" ;
ALTER TABLE pt_mstr
ADD `pt_wh` Boolean NULL default true comment "Indicates whether the item may be stored in, issued from or received into an external warehouse, and therefore whether information about the item should be automatically exported to active external warehouses as the item data is maintained." ;
ALTER TABLE pt_mstr
ADD `pt_btb_type` varchar(2) NULL default null comment "Default BTB Designation for orders for this item." ;
ALTER TABLE pt_mstr
ADD `pt_cfg_type` varchar(1) NULL default null comment "Configuration Type: 1-Assembly, 2-Kit" ;
ALTER TABLE pt_mstr
ADD `pt_app_owner` varchar(12) NULL default null comment "Identifies the external application that created and will maintain information about the item." ;
ALTER TABLE pt_mstr
ADD `pt_op_yield` Boolean NULL default false comment "Determines if Op Based Yield calculations are enabled for this item." ;
ALTER TABLE pt_mstr
ADD `pt_run_seq1` varchar(8) NULL default null comment "The primary sequence items are scheduled on a production line." ;
ALTER TABLE pt_mstr
ADD `pt_run_seq2` varchar(8) NULL default null comment "The secondary sequence items are scheduled on a production line." ;
ALTER TABLE pt_mstr
ADD `pt_atp_enforcement` varchar(1) NULL default 0 comment "ATP Enforcement: 0=None, 1=Issue Warning, 2=Issue Error." ;
ALTER TABLE pt_mstr
ADD `pt_atp_family` Boolean NULL default false comment "Check family items in ATP Enforcement." ;
ALTER TABLE pt_mstr
ADD `pt_domain` varchar(8) NULL default null comment "The business domain for this data." ;
ALTER TABLE pt_mstr
ADD `oid_pt_mstr` decimal(28,9) NULL default 0 comment "Unique application generated record identifier." ;
ALTER TABLE pt_mstr ADD INDEX pt_routing(pt_domain,pt_routing,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_network(pt_domain,pt_network,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_model(pt_domain,pt_model);
ALTER TABLE pt_mstr ADD INDEX pt_bom_code(pt_domain,pt_bom_code,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_svc_group(pt_domain,pt_svc_group);
ALTER TABLE pt_mstr ADD INDEX pt_part_type(pt_domain,pt_part_type,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_pm_mrp(pt_domain,pt_pm_mrp,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_user3(pt_domain,pt_user3,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_part(pt_domain,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_group(pt_domain,pt_group,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_prod_part(pt_domain,pt_prod_line,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_pvm_bom(pt_domain,pt_pvm_bom,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_desc(pt_domain,pt_desc1,pt_desc2,pt_part);
ALTER TABLE pt_mstr ADD INDEX pt_ll_mrp_pt(pt_domain,pt_ll_code,pt_mrp,pt_part);
