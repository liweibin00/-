/*package com.mytest.ProConversion;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class test {

    public static void main(String[] args) throws IOException {
        List<Msql> arrayMsqls = new ArrayList<>();

        Msql msqls = new Msql();

        for (int i = 0; i < 5; i++) {
            msqls.setFieldName("pt_part" + i);
            msqls.setDataType("char");
            msqls.setFormat("10");
            msqls.setDesc("");
            msqls.setInit("");
            arrayMsqls.add(msqls);
            //System.out.println(arrayMsqls.get(i).getFieldName());
        }

        MysqlFile mysqlFile = new MysqlFile(arrayMsqls);

        mysqlFile.CreateTable("pt_mstr");
        mysqlFile.AddField("pt_mstr");
    }
}*/
